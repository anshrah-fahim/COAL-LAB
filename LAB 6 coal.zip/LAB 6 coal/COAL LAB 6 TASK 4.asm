.model small
.stack 100h
.data
msg1 db 'the user entered',' $'
msg2 db 'character.$'
char db ? ;to store the input 



.code
main proc
    mov ax, @data
    mov ds, ax
    mov ah, 1
    int 21h
    mov char, al
    mov dx, 10
    mov ah, 2
    int 21h
    mov dx, 13
    mov ah, 2
    int 21h  
    mov ax, offset msg1
    mov ah, 9
    int 21h
    mov dl, char
    mov ah, 2
    int 21h
    mov dx, offset msg2
    mov ah, 9
    int 21h
    mov ah, 4ch
    int 21h
    main endp
end main




