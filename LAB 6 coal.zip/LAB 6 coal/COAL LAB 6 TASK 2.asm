.model small
.stack 100h
.data
Msg1 DB 'Hello$'
Msg2 DB 'World$'
.code
main proc
    mov ax, @data
    mov ds, ax
    mov dl, msg1
    mov dx, offset msg1
    mov ah,9
    int 21h
    mov dx, 10
    mov ah, 2
    int 21h
    mov dx, 13
    mov ah, 2
    int 21h
    mov ax, @data
    mov ds, ax
    mov dl, msg2
    mov dx, offset msg2
    mov ah, 9
    int 21h
    mov ah, 4ch
    int 21h
    main endp
end main




