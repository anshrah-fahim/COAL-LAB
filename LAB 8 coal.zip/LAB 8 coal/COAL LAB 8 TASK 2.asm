.model small
.stack 100h
.data
    msg1 DB 'numbers are: $'
    msg2 DB 0DH,0AH,'Sum is: $'
.code
main proc
   mov ax,@data
   mov ds,ax
   mov ah,9
   mov dx,Offset msg1
   int 21h
    mov cx,4      
    mov dl,48     
    mov bl,0     
printLoop:
    mov ah,2
    int 21h
    mov al,dl
    sub al,48
    add bl,al
    inc dl
    LOOP printLoop
    mov dl,0DH
    mov ah,2
    int  21h
    mov dl,0AH
    mov ah,2
  int 21h
    mov ah,9
    mov dx,Offset msg2
    int 21h
    mov al,bl
    add al,48
    mov dl,al
    mov ah,2
    int 21h
    mov ah,4ch
    int 21h
main endp
end main




